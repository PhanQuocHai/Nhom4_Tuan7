require('dotenv').config();  // Load biến môi trường từ file .env

if (!process.env.PROD_URI || process.env.PROD_URI.trim() === "undefined") {
    throw new Error("❌ Database URL is not defined! Check your .env file.");
}

const PROD_URI = process.env.PROD_URI.trim();  // Chỉ khai báo một lần
console.log("✅ Connecting to:", PROD_URI);


const MongoClient = require('mongodb').MongoClient

// Note: A production application should not expose database credentials in plain text.
// For strategies on handling credentials, visit 12factor: https://12factor.net/config.
// const MKTG_URI = "mongodb://<dbuser>:<dbpassword>@<host1>:<port1>,<host2>:<port2>/<dbname>?replicaSet=<replicaSetName>"

var dbs = {production: {}};

function connect(url) {
  if (!url) {
      throw new Error("❌ Database URL is not defined!");
  }
  return MongoClient.connect(url)
      .then(client => client.db())
      .catch(err => {
          console.error("❌ MongoDB connection error:", err);
          throw err;
      });
}


exports.initdb = async function () {
  let database = await connect(process.env.PROD_URI);
  dbs.production = database;
}


exports.dbs = dbs;
console.log("🔗 Connecting to:", process.env.PROD_URI);
